function changeData(url, val) {
  location = url + val;
}
