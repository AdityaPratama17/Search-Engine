from django.apps import AppConfig


class ParseConfig(AppConfig):
    name = 'parse'
