from django.contrib import admin

from .models import *

admin.site.register(K)
admin.site.register(S)
admin.site.register(P)
admin.site.register(O)
admin.site.register(Pel)
admin.site.register(Ket)
admin.site.register(FN)
admin.site.register(FV)
admin.site.register(FS)
admin.site.register(Gt)
admin.site.register(Pn)
admin.site.register(Pr)
admin.site.register(Ps)
admin.site.register(Kt)
